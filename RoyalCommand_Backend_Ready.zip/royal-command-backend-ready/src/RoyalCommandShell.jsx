import React, { useState, useMemo, useRef, useEffect, useCallback } from "react";
import { supabase } from "./lib/supabase";
import {
  Globe2, Search, Bell, ChevronDown, ChevronRight, Menu, X,
  Scale, Calculator, Mic, Truck, Building2, Users, ShieldCheck,
  Stethoscope, Landmark, Wrench, Boxes, Plane, HeartHandshake,
  MessageSquare, BarChart3, Settings, LayoutGrid, Radio, PhoneCall,
  FileText, Sparkles, Lock, Mail, Eye, EyeOff, ArrowUpRight, ArrowDownRight,
} from "lucide-react";

/* ------------------------------------------------------------------
   ROYAL COMMAND — GLOBAL UI SHELL
   Token system
   - bg   : slate-950 / slate-900  (#020617 / #0F172A)
   - glass: white/5 + backdrop-blur, border white/10
   - cyan : #00F0FF  (signal / active / data)
   - violet: #8B5CF6 (command / authority)
   - type : display = Sora (tight, geometric) · body = Inter · data = JetBrains Mono
   Signature element: "The Orbit" — a rotating ring of 100 nodes (one per
   market) around the wordmark. It is the login hero AND collapses into a
   live status pip in the dashboard header — the same shape scales from
   "welcome" to "operating," which is the whole pitch of the product.
------------------------------------------------------------------- */

const BRAND_CYAN = "#00F0FF";
const BRAND_VIOLET = "#8B5CF6";

/* ---------------------------- i18n layer ---------------------------- *
 * Every string lives here so ChatGPT / Grok can swap this object for a
 * fetch("/i18n/{locale}.json") call without touching a single component.
 * dir is used to flip the whole shell to RTL (Arabic, Hebrew, Urdu, etc).
 * ---------------------------------------------------------------------- */
const I18N = {
  ko: {
    dir: "ltr",
    tagline1: "COMMAND YOUR DOMAIN",
    tagline2: "지구에서 우주까지",
    signIn: "로그인",
    email: "이메일",
    password: "비밀번호",
    remember: "로그인 상태 유지",
    forgot: "비밀번호를 잊으셨나요?",
    orContinue: "다른 방법으로 계속하기",
    noAccount: "계정이 없으신가요?",
    createAccount: "계정 생성",
    search: "서비스, 고객, 명령 검색…",
    welcome: "환영합니다",
    overview: "오늘의 운영 현황입니다.",
    liveReport: "실시간 AI 주문 · 상담 리포트",
    viewAll: "전체 보기",
    collapse: "메뉴 접기",
    signOut: "로그아웃",
  },
  en: {
    dir: "ltr",
    tagline1: "COMMAND YOUR DOMAIN",
    tagline2: "From Earth to space",
    signIn: "Sign In",
    email: "Email",
    password: "Password",
    remember: "Keep me signed in",
    forgot: "Forgot password?",
    orContinue: "Or continue with",
    noAccount: "Don't have an account?",
    createAccount: "Create account",
    search: "Search services, customers, commands…",
    welcome: "Welcome back",
    overview: "Here's what's operating today.",
    liveReport: "Live AI Order & Consultation Report",
    viewAll: "View all",
    collapse: "Collapse menu",
    signOut: "Sign out",
  },
  es: {
    dir: "ltr",
    tagline1: "COMANDA TU DOMINIO",
    tagline2: "De la Tierra al espacio",
    signIn: "Iniciar sesión",
    email: "Correo electrónico",
    password: "Contraseña",
    remember: "Mantener sesión iniciada",
    forgot: "¿Olvidaste tu contraseña?",
    orContinue: "O continuar con",
    noAccount: "¿No tienes una cuenta?",
    createAccount: "Crear cuenta",
    search: "Buscar servicios, clientes, comandos…",
    welcome: "Bienvenido de nuevo",
    overview: "Esto es lo que opera hoy.",
    liveReport: "Informe en vivo de pedidos IA y consultas",
    viewAll: "Ver todo",
    collapse: "Contraer menú",
    signOut: "Cerrar sesión",
  },
  ar: {
    dir: "rtl",
    tagline1: "قُد نطاقك",
    tagline2: "من الأرض إلى الفضاء",
    signIn: "تسجيل الدخول",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    remember: "إبقائي مسجّلاً للدخول",
    forgot: "هل نسيت كلمة المرور؟",
    orContinue: "أو المتابعة عبر",
    noAccount: "ليس لديك حساب؟",
    createAccount: "إنشاء حساب",
    search: "ابحث عن الخدمات والعملاء والأوامر…",
    welcome: "مرحبًا بعودتك",
    overview: "إليك ما يعمل اليوم.",
    liveReport: "تقرير مباشر لطلبات واستشارات الذكاء الاصطناعي",
    viewAll: "عرض الكل",
    collapse: "طيّ القائمة",
    signOut: "تسجيل الخروج",
  },
};

// Representative slice of the 100-country switcher. Backend should hydrate
// this from /api/markets — shape (code, label, locale) is the contract.
const MARKETS = [
  { code: "KR", label: "대한민국 · 한국어", locale: "ko" },
  { code: "US", label: "United States · English", locale: "en" },
  { code: "GB", label: "United Kingdom · English", locale: "en" },
  { code: "ES", label: "España · Español", locale: "es" },
  { code: "MX", label: "México · Español", locale: "es" },
  { code: "AE", label: "الإمارات · العربية", locale: "ar" },
  { code: "SA", label: "السعودية · العربية", locale: "ar" },
  { code: "JP", label: "日本 · 日本語", locale: "en" },
  { code: "AU", label: "Australia · English", locale: "en" },
  { code: "DE", label: "Deutschland · Deutsch", locale: "en" },
];

// 20+ service verticals for the sidebar. `key` is what gets wired to
// routing / permissions on the backend.
const SERVICES = [
  { key: "overview", label: { ko: "대시보드", en: "Dashboard" }, icon: LayoutGrid },
  { key: "legal", label: { ko: "법률", en: "Legal" }, icon: Scale },
  { key: "accounting", label: { ko: "회계", en: "Accounting" }, icon: Calculator },
  { key: "ai_voice", label: { ko: "AI 보이스", en: "AI Voice" }, icon: Mic },
  { key: "delivery", label: { ko: "배송", en: "Delivery" }, icon: Truck },
  { key: "real_estate", label: { ko: "부동산", en: "Real Estate" }, icon: Building2 },
  { key: "hr", label: { ko: "인사관리", en: "HR & Payroll" }, icon: Users },
  { key: "compliance", label: { ko: "컴플라이언스", en: "Compliance" }, icon: ShieldCheck },
  { key: "health", label: { ko: "헬스케어", en: "Healthcare" }, icon: Stethoscope },
  { key: "finance", label: { ko: "금융", en: "Finance" }, icon: Landmark },
  { key: "maintenance", label: { ko: "시설관리", en: "Maintenance" }, icon: Wrench },
  { key: "inventory", label: { ko: "재고관리", en: "Inventory" }, icon: Boxes },
  { key: "travel", label: { ko: "출장/여행", en: "Travel" }, icon: Plane },
  { key: "concierge", label: { ko: "컨시어지", en: "Concierge" }, icon: HeartHandshake },
  { key: "support", label: { ko: "고객상담", en: "Support" }, icon: MessageSquare },
  { key: "analytics", label: { ko: "분석", en: "Analytics" }, icon: BarChart3 },
  { key: "dispatch", label: { ko: "AI 디스패치", en: "AI Dispatch" }, icon: Radio },
  { key: "call_center", label: { ko: "콜센터", en: "Call Center" }, icon: PhoneCall },
  { key: "contracts", label: { ko: "계약관리", en: "Contracts" }, icon: FileText },
  { key: "automation", label: { ko: "자동화", en: "Automation" }, icon: Sparkles },
  { key: "settings", label: { ko: "설정", en: "Settings" }, icon: Settings },
];

/* ---------------------------- The Orbit ---------------------------- *
 * Signature visual. A ring of small nodes (sampled down from 100 for
 * render cost) rotating slowly behind the wordmark on login, and a
 * compact pulsing pip version in the dashboard header.
 * ---------------------------------------------------------------------- */
function Orbit({ size = 340, nodeCount = 48, compact = false }) {
  const nodes = useMemo(
    () => Array.from({ length: nodeCount }, (_, i) => i),
    [nodeCount]
  );
  if (compact) {
    return (
      <span className="relative inline-flex h-2.5 w-2.5">
        <span
          className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60"
          style={{ backgroundColor: BRAND_CYAN }}
        />
        <span
          className="relative inline-flex h-2.5 w-2.5 rounded-full"
          style={{ backgroundColor: BRAND_CYAN }}
        />
      </span>
    );
  }
  return (
    <div
      className="pointer-events-none absolute inset-0 mx-auto flex items-center justify-center"
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <div className="absolute inset-0 rounded-full border border-white/10" />
      <div className="absolute inset-8 rounded-full border border-white/[0.08]" />
      <div className="absolute inset-16 rounded-full border border-white/[0.06]" />
      <div
        className="absolute inset-0 animate-[spin_36s_linear_infinite] rounded-full"
        style={{ width: size, height: size }}
      >
        {nodes.map((i) => {
          const angle = (i / nodeCount) * 2 * Math.PI;
          const r = size / 2;
          const x = r + r * Math.cos(angle);
          const y = r + r * Math.sin(angle);
          const isKey = i % 6 === 0;
          return (
            <span
              key={i}
              className="absolute rounded-full"
              style={{
                left: x,
                top: y,
                width: isKey ? 5 : 2.5,
                height: isKey ? 5 : 2.5,
                transform: "translate(-50%,-50%)",
                backgroundColor: isKey ? BRAND_CYAN : "rgba(148,163,184,0.5)",
                boxShadow: isKey ? `0 0 8px ${BRAND_CYAN}` : "none",
              }}
            />
          );
        })}
      </div>
      <div
        className="absolute h-24 w-24 animate-[spin_28s_linear_infinite_reverse] rounded-full blur-2xl opacity-30"
        style={{ background: `radial-gradient(circle, ${BRAND_VIOLET}, transparent 70%)` }}
      />
    </div>
  );
}

/* ---------------------------- Language switcher ---------------------------- */
function LanguageSwitcher({ locale, onChange, markets = MARKETS }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = markets.find((m) => m.locale === locale) || markets[0];

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-200 backdrop-blur-xl transition hover:border-white/20 hover:bg-white/10"
      >
        <Globe2 className="h-4 w-4" style={{ color: BRAND_CYAN }} />
        <span className="hidden sm:inline">{current.label}</span>
        <span className="sm:hidden">{current.code}</span>
        <ChevronDown className={`h-3.5 w-3.5 text-slate-400 transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="absolute end-0 z-50 mt-2 w-64 overflow-hidden rounded-xl border border-white/10 bg-slate-900/95 backdrop-blur-xl shadow-2xl shadow-black/50">
          <div className="max-h-72 overflow-y-auto py-1">
            {markets.map((m) => (
              <button
                key={m.code}
                onClick={() => {
                  onChange(m);
                  setOpen(false);
                }}
                className={`flex w-full items-center justify-between px-4 py-2.5 text-start text-sm transition hover:bg-white/5 ${
                  m.code === current.code ? "text-cyan-300" : "text-slate-300"
                }`}
              >
                <span>{m.label}</span>
                {m.code === current.code && (
                  <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: BRAND_CYAN }} />
                )}
              </button>
            ))}
          </div>
          <div className="border-t border-white/10 px-4 py-2 text-[11px] text-slate-500">
            100+ markets · synced from /api/markets
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Header ---------------------------- */
function Header({ t, locale, onLocaleChange, onToggleSidebar, showSearch, showMenuButton, userName = "Harry Park" }) {
  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-white/10 bg-slate-950/70 px-4 backdrop-blur-xl sm:px-6">
      <div className="flex items-center gap-3">
        {showMenuButton && (
          <button
            onClick={onToggleSidebar}
            className="rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10 lg:hidden"
            aria-label={t.collapse}
          >
            <Menu className="h-4 w-4" />
          </button>
        )}
        <Logo compact />
      </div>

      {showSearch && (
        <div className="hidden max-w-md flex-1 items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 md:flex">
          <Search className="h-4 w-4 text-slate-500" />
          <input
            type="text"
            placeholder={t.search}
            className="w-full bg-transparent text-sm text-slate-200 placeholder-slate-500 outline-none"
          />
        </div>
      )}

      <div className="flex items-center gap-2 sm:gap-3">
        <LanguageSwitcher locale={locale} onChange={onLocaleChange} />
        <button className="relative rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10">
          <Bell className="h-4 w-4" />
          <span
            className="absolute -end-0.5 -top-0.5 h-2 w-2 rounded-full ring-2 ring-slate-950"
            style={{ backgroundColor: BRAND_CYAN }}
          />
        </button>
        <button className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 py-1.5 ps-1.5 pe-3 hover:bg-white/10">
          <span
            className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold text-slate-950"
            style={{ background: `linear-gradient(135deg, ${BRAND_CYAN}, ${BRAND_VIOLET})` }}
          >
            {userName.slice(0, 1)}
          </span>
          <span className="hidden text-sm text-slate-200 sm:inline">{userName}</span>
        </button>
      </div>
    </header>
  );
}

function Logo({ compact = false }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="flex h-8 w-8 items-center justify-center rounded-lg"
        style={{ background: `linear-gradient(135deg, ${BRAND_CYAN}, ${BRAND_VIOLET})` }}
      >
        <span className="text-sm font-bold text-slate-950" style={{ fontFamily: "'Sora', sans-serif" }}>
          R
        </span>
      </div>
      {!compact && (
        <span className="text-lg font-semibold tracking-tight text-white" style={{ fontFamily: "'Sora', sans-serif" }}>
          ROYAL COMMAND
        </span>
      )}
      {compact && (
        <span className="hidden text-sm font-semibold tracking-wide text-white sm:inline" style={{ fontFamily: "'Sora', sans-serif" }}>
          ROYAL COMMAND
        </span>
      )}
    </div>
  );
}

/* ---------------------------- Login screen ---------------------------- */
function LoginScreen({ t, locale, onLocaleChange, onSubmit, onSignUp, onResetPassword, onOAuth, loading, error }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [mode, setMode] = useState("signin");
  const [notice, setNotice] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setNotice("");
    if (mode === "signin") {
      await onSubmit({ email, password });
    } else {
      const result = await onSignUp({ email, password });
      if (result?.needsEmailConfirmation) {
        setNotice(locale === "ko" ? "확인 이메일을 보냈습니다." : "Check your email to confirm your account.");
      }
    }
  }

  async function handleReset() {
    if (!email) {
      setNotice(locale === "ko" ? "먼저 이메일을 입력해 주세요." : "Enter your email first.");
      return;
    }
    const ok = await onResetPassword(email);
    if (ok) setNotice(locale === "ko" ? "비밀번호 재설정 이메일을 보냈습니다." : "Password reset email sent.");
  }

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-slate-950">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 50% at 50% 0%, rgba(139,92,246,0.14), transparent 60%), radial-gradient(40% 40% at 85% 90%, rgba(0,240,255,0.08), transparent 60%)",
        }}
      />
      <div className="pointer-events-none absolute inset-0 opacity-[0.04]" style={{
        backgroundImage: "linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)",
        backgroundSize: "48px 48px",
      }} />

      <div className="relative z-10 flex items-center justify-between px-6 py-6 sm:px-10">
        <Logo />
        <LanguageSwitcher locale={locale} onChange={onLocaleChange} />
      </div>

      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 pb-16">
        <div className="relative mb-6 flex h-40 w-full items-center justify-center sm:h-52">
          <Orbit size={280} nodeCount={48} />
          <div className="relative text-center">
            <p className="text-xs font-medium tracking-[0.3em] text-slate-500">GLOBAL AI OPERATING PLATFORM</p>
          </div>
        </div>

        <div className="mb-8 text-center">
          <h1
            className="text-3xl font-bold tracking-tight text-white sm:text-4xl"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            {t.tagline1}
          </h1>
          <p className="mt-1.5 text-base text-transparent bg-clip-text" style={{
            backgroundImage: `linear-gradient(90deg, ${BRAND_CYAN}, ${BRAND_VIOLET})`,
          }}>
            {t.tagline2}
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="w-full max-w-sm rounded-2xl border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/40 backdrop-blur-2xl sm:p-8"
        >
          <div className="mb-5 grid grid-cols-2 gap-2 rounded-lg bg-white/[0.03] p-1">
            <button
              type="button"
              onClick={() => setMode("signin")}
              className={`rounded-md py-2 text-xs font-medium ${mode === "signin" ? "bg-white/10 text-white" : "text-slate-400"}`}
            >
              {t.signIn}
            </button>
            <button
              type="button"
              onClick={() => setMode("signup")}
              className={`rounded-md py-2 text-xs font-medium ${mode === "signup" ? "bg-white/10 text-white" : "text-slate-400"}`}
            >
              {t.createAccount}
            </button>
          </div>

          <label className="mb-1.5 block text-xs font-medium text-slate-400">{t.email}</label>
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-white/10 bg-slate-950/40 px-3 py-2.5 focus-within:border-cyan-400/50">
            <Mail className="h-4 w-4 shrink-0 text-slate-500" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-transparent text-sm text-slate-200 outline-none"
              placeholder="you@company.com"
              autoComplete="email"
            />
          </div>

          <label className="mb-1.5 block text-xs font-medium text-slate-400">{t.password}</label>
          <div className="mb-2 flex items-center gap-2 rounded-lg border border-white/10 bg-slate-950/40 px-3 py-2.5 focus-within:border-cyan-400/50">
            <Lock className="h-4 w-4 shrink-0 text-slate-500" />
            <input
              type={showPw ? "text" : "password"}
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent text-sm text-slate-200 outline-none"
              placeholder="••••••••"
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
            />
            <button type="button" onClick={() => setShowPw((v) => !v)} className="shrink-0 text-slate-500 hover:text-slate-300">
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>

          <div className="mb-6 flex items-center justify-between text-xs">
            <label className="flex items-center gap-2 text-slate-400">
              <input type="checkbox" className="h-3.5 w-3.5 rounded border-white/20 bg-transparent accent-cyan-400" />
              {t.remember}
            </label>
            {mode === "signin" && (
              <button type="button" onClick={handleReset} className="text-slate-400 hover:text-cyan-300">
                {t.forgot}
              </button>
            )}
          </div>

          {(error || notice) && (
            <div className={`mb-4 rounded-lg border px-3 py-2 text-xs ${error ? "border-rose-400/30 bg-rose-400/10 text-rose-200" : "border-cyan-400/20 bg-cyan-400/10 text-cyan-100"}`}>
              {error || notice}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg py-2.5 text-sm font-semibold text-slate-950 transition hover:brightness-110 active:brightness-95 disabled:cursor-not-allowed disabled:opacity-60"
            style={{ background: `linear-gradient(90deg, ${BRAND_CYAN}, ${BRAND_VIOLET})` }}
          >
            {loading ? (locale === "ko" ? "처리 중…" : "Working…") : (mode === "signin" ? t.signIn : t.createAccount)}
          </button>

          <div className="my-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-white/10" />
            <span className="text-[11px] text-slate-500">{t.orContinue}</span>
            <div className="h-px flex-1 bg-white/10" />
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              ["Google", "google"],
              ["Microsoft", "azure"],
              ["Apple", "apple"],
            ].map(([label, provider]) => (
              <button
                key={provider}
                type="button"
                onClick={() => onOAuth(provider)}
                className="rounded-lg border border-white/10 bg-white/[0.03] py-2 text-[11px] text-slate-300 transition hover:bg-white/[0.08]"
              >
                {label}
              </button>
            ))}
          </div>
        </form>
      </main>
    </div>
  );
}

/* ---------------------------- Sidebar ---------------------------- */
function Sidebar({ t, locale, active, onSelect, collapsed, onToggleCollapse, mobileOpen, onCloseMobile }) {
  const content = (
    <nav className="flex h-full flex-col">
      <div className="flex items-center justify-between px-4 py-4">
        {!collapsed && <span className="text-xs font-semibold tracking-widest text-slate-500">SERVICES</span>}
        <button
          onClick={onToggleCollapse}
          className="hidden rounded-md border border-white/10 bg-white/5 p-1.5 text-slate-400 hover:bg-white/10 lg:flex"
          aria-label={t.collapse}
        >
          <ChevronRight className={`h-3.5 w-3.5 transition ${collapsed ? "" : "rotate-180"}`} />
        </button>
        <button onClick={onCloseMobile} className="rounded-md border border-white/10 bg-white/5 p-1.5 text-slate-400 lg:hidden">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-4">
        {SERVICES.map((s) => {
          const Icon = s.icon;
          const isActive = s.key === active;
          const label = s.label[locale] || s.label.en;
          return (
            <button
              key={s.key}
              onClick={() => onSelect(s.key)}
              title={collapsed ? label : undefined}
              className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
                isActive
                  ? "bg-white/10 text-white"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              }`}
              style={isActive ? { boxShadow: `inset 2px 0 0 0 ${BRAND_CYAN}` } : undefined}
            >
              <Icon className="h-4 w-4 shrink-0" style={{ color: isActive ? BRAND_CYAN : undefined }} />
              {!collapsed && <span className="truncate">{label}</span>}
            </button>
          );
        })}
      </div>
    </nav>
  );

  return (
    <>
      {/* desktop */}
      <aside
        className={`hidden shrink-0 border-e border-white/10 bg-slate-950/60 backdrop-blur-xl transition-all duration-200 lg:block ${
          collapsed ? "w-[76px]" : "w-64"
        }`}
      >
        {content}
      </aside>

      {/* mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={onCloseMobile} />
          <aside className="absolute inset-y-0 start-0 w-72 border-e border-white/10 bg-slate-950/95 backdrop-blur-xl">
            {content}
          </aside>
        </div>
      )}
    </>
  );
}

/* ---------------------------- Dashboard ---------------------------- */
function Dashboard({ t, locale, userName, onLocaleChange, onSignOut, stats, recentRuns, dataLoading }) {
  const [active, setActive] = useState("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const kpis = [
    { key: "rooms", label: { ko: "내 Room", en: "My Rooms" }, value: String(stats.rooms ?? 0) },
    { key: "messages", label: { ko: "메시지", en: "Messages" }, value: String(stats.messages ?? 0) },
    { key: "runs", label: { ko: "AI 실행", en: "AI Runs" }, value: String(stats.aiRuns ?? 0) },
    { key: "services", label: { ko: "활성 서비스", en: "Active Services" }, value: String(stats.activeServices ?? 0) },
  ];

  const statusStyle = {
    completed: { dot: "#34D399", text: "text-emerald-300", ko: "완료", en: "Completed" },
    success: { dot: "#34D399", text: "text-emerald-300", ko: "완료", en: "Completed" },
    running: { dot: BRAND_CYAN, text: "text-cyan-300", ko: "진행중", en: "Running" },
    pending: { dot: "#94A3B8", text: "text-slate-400", ko: "대기", en: "Pending" },
    failed: { dot: "#FB7185", text: "text-rose-300", ko: "실패", en: "Failed" },
  };

  return (
    <div className="flex h-screen flex-col bg-slate-950">
      <Header
        t={t}
        locale={locale}
        onLocaleChange={onLocaleChange}
        onToggleSidebar={() => setMobileOpen(true)}
        showSearch
        showMenuButton
        userName={userName}
      />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          t={t}
          locale={locale}
          active={active}
          onSelect={(key) => {
            setActive(key);
            setMobileOpen(false);
          }}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((v) => !v)}
          mobileOpen={mobileOpen}
          onCloseMobile={() => setMobileOpen(false)}
        />

        <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-xl font-semibold text-white sm:text-2xl" style={{ fontFamily: "'Sora', sans-serif" }}>
                {t.welcome}, {userName.split(" ")[0]}
              </h1>
              <p className="mt-0.5 text-sm text-slate-400">{t.overview}</p>
            </div>
            <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5">
              <Orbit compact />
              <span className="text-xs text-slate-400">{locale === "ko" ? "Supabase 실시간 연결" : "Supabase live"}</span>
            </div>
          </div>

          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {kpis.map((k) => (
              <div key={k.key} className="rounded-xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-xl">
                <p className="text-xs text-slate-400">{k.label[locale] || k.label.en}</p>
                <div className="mt-2 flex items-end justify-between">
                  <span className="text-2xl font-semibold text-white" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {dataLoading ? "…" : k.value}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-white/10 bg-white/[0.04] backdrop-blur-xl">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <div className="flex items-center gap-2">
                <Orbit compact />
                <h2 className="text-sm font-semibold text-slate-200">
                  {locale === "ko" ? "최근 AI 실행" : "Recent AI Runs"}
                </h2>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-start text-sm">
                <thead>
                  <tr className="text-xs text-slate-500">
                    <th className="px-5 py-3 text-start font-medium">ID</th>
                    <th className="px-5 py-3 text-start font-medium">{locale === "ko" ? "요청" : "Prompt"}</th>
                    <th className="px-5 py-3 text-start font-medium">{locale === "ko" ? "상태" : "Status"}</th>
                    <th className="px-5 py-3 text-start font-medium">{locale === "ko" ? "처리시간" : "Latency"}</th>
                  </tr>
                </thead>
                <tbody>
                  {!dataLoading && recentRuns.length === 0 && (
                    <tr className="border-t border-white/5">
                      <td colSpan={4} className="px-5 py-8 text-center text-sm text-slate-500">
                        {locale === "ko" ? "아직 AI 실행 기록이 없습니다." : "No AI runs yet."}
                      </td>
                    </tr>
                  )}
                  {recentRuns.map((row) => {
                    const st = statusStyle[row.status] || statusStyle.pending;
                    return (
                      <tr key={row.id} className="border-t border-white/5 text-slate-300">
                        <td className="px-5 py-3 font-mono text-xs text-slate-400">{row.id.slice(0, 8)}</td>
                        <td className="max-w-[520px] truncate px-5 py-3">{row.prompt}</td>
                        <td className="px-5 py-3">
                          <span className={`inline-flex items-center gap-1.5 text-xs ${st.text}`}>
                            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: st.dot }} />
                            {locale === "ko" ? st.ko : st.en}
                          </span>
                        </td>
                        <td className="px-5 py-3 font-mono text-xs text-slate-400">
                          {row.latency_ms == null ? "—" : `${row.latency_ms} ms`}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <button onClick={onSignOut} className="mt-6 text-xs text-slate-500 hover:text-slate-300">
            {t.signOut}
          </button>
        </main>
      </div>
    </div>
  );
}

/* ---------------------------- Root shell ---------------------------- */
export default function RoyalCommandShell() {
  const [locale, setLocale] = useState("ko");
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authActionLoading, setAuthActionLoading] = useState(false);
  const [authError, setAuthError] = useState("");
  const [dataLoading, setDataLoading] = useState(false);
  const [stats, setStats] = useState({ rooms: 0, messages: 0, aiRuns: 0, activeServices: 0 });
  const [recentRuns, setRecentRuns] = useState([]);

  const t = I18N[locale] || I18N.en;

  const loadProfile = useCallback(async (user) => {
    if (!user) {
      setProfile(null);
      return;
    }

    const { data, error } = await supabase
      .from("profiles")
      .select("id,email,full_name,default_language,avatar_url,role")
      .eq("id", user.id)
      .single();

    if (error) {
      console.error("Profile load failed:", error);
      setProfile({
        id: user.id,
        email: user.email,
        full_name: user.user_metadata?.full_name || user.email?.split("@")[0] || "User",
        role: "client",
      });
      return;
    }

    setProfile(data);
    if (data?.default_language?.startsWith("ko")) setLocale("ko");
    else if (data?.default_language?.startsWith("es")) setLocale("es");
    else if (data?.default_language?.startsWith("ar")) setLocale("ar");
    else setLocale("en");
  }, []);

  const loadDashboard = useCallback(async (userId) => {
    if (!userId) return;
    setDataLoading(true);

    try {
      const { data: rooms, error: roomsError } = await supabase
        .from("rooms")
        .select("id,status")
        .order("updated_at", { ascending: false });

      if (roomsError) throw roomsError;

      const roomIds = (rooms || []).map((r) => r.id);
      if (roomIds.length === 0) {
        setStats({ rooms: 0, messages: 0, aiRuns: 0, activeServices: 0 });
        setRecentRuns([]);
        return;
      }

      const [messagesResult, runsCountResult, servicesResult, runsResult] = await Promise.all([
        supabase.from("messages").select("id", { count: "exact", head: true }).in("room_id", roomIds),
        supabase.from("ai_runs").select("id", { count: "exact", head: true }).in("room_id", roomIds),
        supabase.from("service_instances").select("id", { count: "exact", head: true }).in("room_id", roomIds).eq("status", "active"),
        supabase
          .from("ai_runs")
          .select("id,room_id,prompt,status,latency_ms,created_at")
          .in("room_id", roomIds)
          .order("created_at", { ascending: false })
          .limit(10),
      ]);

      if (messagesResult.error) throw messagesResult.error;
      if (runsCountResult.error) throw runsCountResult.error;
      if (servicesResult.error) throw servicesResult.error;
      if (runsResult.error) throw runsResult.error;

      setStats({
        rooms: roomIds.length,
        messages: messagesResult.count || 0,
        aiRuns: runsCountResult.count || 0,
        activeServices: servicesResult.count || 0,
      });
      setRecentRuns(runsResult.data || []);
    } catch (error) {
      console.error("Dashboard load failed:", error);
      setAuthError(error.message || "Dashboard data could not be loaded.");
    } finally {
      setDataLoading(false);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session: initialSession } }) => {
      if (!mounted) return;
      setSession(initialSession);
      setAuthLoading(false);
      if (initialSession?.user) {
        loadProfile(initialSession.user);
        loadDashboard(initialSession.user.id);
      }
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setAuthError("");
      if (nextSession?.user) {
        loadProfile(nextSession.user);
        loadDashboard(nextSession.user.id);
      } else {
        setProfile(null);
        setStats({ rooms: 0, messages: 0, aiRuns: 0, activeServices: 0 });
        setRecentRuns([]);
      }
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [loadProfile, loadDashboard]);

  useEffect(() => {
    if (!session?.user) return;

    const channel = supabase
      .channel(`royal-command-dashboard-${session.user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => loadDashboard(session.user.id))
      .on("postgres_changes", { event: "*", schema: "public", table: "ai_runs" }, () => loadDashboard(session.user.id))
      .on("postgres_changes", { event: "*", schema: "public", table: "service_instances" }, () => loadDashboard(session.user.id))
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session?.user, loadDashboard]);

  function handleLocaleChange(market) {
    setLocale(market.locale);
  }

  async function handleLogin({ email, password }) {
    setAuthActionLoading(true);
    setAuthError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setAuthError(error.message);
    setAuthActionLoading(false);
  }

  async function handleSignUp({ email, password }) {
    setAuthActionLoading(true);
    setAuthError("");

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: email.split("@")[0],
          default_language: locale === "ko" ? "ko-KR" : locale === "es" ? "es" : locale === "ar" ? "ar" : "en-AU",
          role: "client",
        },
      },
    });

    if (error) {
      setAuthError(error.message);
      setAuthActionLoading(false);
      return { needsEmailConfirmation: false };
    }

    setAuthActionLoading(false);
    return { needsEmailConfirmation: !data.session };
  }

  async function handleResetPassword(email) {
    setAuthError("");
    const redirectTo = `${window.location.origin}/`;
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
    if (error) {
      setAuthError(error.message);
      return false;
    }
    return true;
  }

  async function handleOAuth(provider) {
    setAuthError("");
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: window.location.origin },
    });
    if (error) setAuthError(error.message);
  }

  async function handleSignOut() {
    setAuthError("");
    const { error } = await supabase.auth.signOut();
    if (error) setAuthError(error.message);
  }

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-sm text-slate-400">
        Royal Command…
      </div>
    );
  }

  const userName =
    profile?.full_name ||
    session?.user?.user_metadata?.full_name ||
    session?.user?.email?.split("@")[0] ||
    "User";

  return (
    <div dir={t.dir} className="font-sans" style={{ fontFamily: "'Inter', sans-serif" }}>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Sora:wght@600;700;800&family=JetBrains+Mono:wght@500;600&display=swap');
      `}</style>

      {!session ? (
        <LoginScreen
          t={t}
          locale={locale}
          onLocaleChange={handleLocaleChange}
          onSubmit={handleLogin}
          onSignUp={handleSignUp}
          onResetPassword={handleResetPassword}
          onOAuth={handleOAuth}
          loading={authActionLoading}
          error={authError}
        />
      ) : (
        <Dashboard
          t={t}
          locale={locale}
          userName={userName}
          onLocaleChange={handleLocaleChange}
          onSignOut={handleSignOut}
          stats={stats}
          recentRuns={recentRuns}
          dataLoading={dataLoading}
        />
      )}
    </div>
  );
}
