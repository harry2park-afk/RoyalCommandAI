# Royal Command — Supabase backend-ready shell

This package converts the supplied UI prototype into a real Supabase-backed React shell.

## What changed

- Real Supabase email/password sign-in
- Real account creation
- Password-reset email
- Google / Microsoft(Azure) / Apple OAuth hooks
- Existing `profiles` table used for the signed-in user's name/language/role
- Existing `rooms`, `messages`, `ai_runs`, `service_instances` tables used for dashboard data
- Realtime refresh on messages, AI runs and service changes
- Existing Supabase RLS policies remain the security boundary
- Removed fake KPI/revenue/order data from the prototype

## Install

```bash
npm install @supabase/supabase-js
```

Copy `.env.example` to `.env.local`, then insert your Supabase publishable key.

For Vercel, add the same two variables to Project Settings → Environment Variables.

## File placement

- `src/RoyalCommandShell.jsx`
- `src/lib/supabase.js`

Import `RoyalCommandShell` from your app entry point.

## Important

OAuth buttons work only after each provider is enabled/configured in Supabase Authentication.
The dashboard intentionally shows only data supported by the current RoyalCommand database schema.
